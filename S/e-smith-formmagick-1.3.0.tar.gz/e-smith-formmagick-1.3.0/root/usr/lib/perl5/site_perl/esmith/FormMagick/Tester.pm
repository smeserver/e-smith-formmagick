#!/usr/bin/perl -w 

#----------------------------------------------------------------------
# Copyright 1999-2003 Mitel Networks Corporation
# This program is free software; you can redistribute it and/or
# modify it under the same terms as Perl itself.
#
# $Id: Tester.pm,v 1.1 2002/02/26 20:45:27 skud Exp $
#----------------------------------------------------------------------

package    esmith::FormMagick::Tester;

my $VERSION = $VERSION = "0.10";

use WWW::Automate;
use strict;
use Carp;

our @ISA = qw(WWW::Automate Exporter);
our @EXPORT = qw( mode );

=pod 

=head1 NAME

esmith::FormMagick::Tester - test esmith FormMagick applications

=head1 SYNOPSIS

  use esmith::FormMagick::Tester;

  my $agent = esmith::FormMagick::Tester->new(
        password => $admin_password,
        host     => $hostname_or_ip,
  );

  $agent->get_panel($panel);    # eg 'useraccounts'

  $agent->set_language('en');
  $agent->set_language(['fr', 'en']);

=head1 DESCRIPTION

esmith::FormMagick::Tester is a subclass of WWW::Automate, which is in
turn a subclass of LWP::UserAgent.  Read the documentation for
WWW::Automate to get a better idea of how to use it effectively.

=head2 new($admin_password)

Create a new agent for testing esmith FormMagick applications
(specifically, the web manager).  It takes a hash of arguments, which
include:

    password        administrative password for the manager
                    (defaults to "default")
    host            hostname or IP to test against
                    (defaults to localhost)

=begin testing
BEGIN: {
    use_ok('WWW::Automate');
    use_ok('esmith::FormMagick::Tester');
    use vars qw($agent);
}

ok(esmith::FormMagick::Tester->can('new'), "We can call new");

ok($agent = esmith::FormMagick::Tester->new(), "create agent object");
isa_ok($agent, 'esmith::FormMagick::Tester');

=end testing

=cut

sub new {
    shift;
    my %args = @_;
    my $self = \%args;

    $self->{password} ||= "default";
    $self->{host}     ||= "127.0.0.1";

    bless $self;
    return $self;
}

=head2 $agent->get_panel($panel)

Gets a panel from the web manager, calling WWW::Automate::get with a URL
built from $agent->{host} and the name of the panel you supply.

=cut

sub get_panel {
    my ($self, $panel) = @_;
    $self->get("http://$self->{host}/server-manager/cgi-bin/$panel");
}

=head2 $agent->set_language($lang)

Sets the language to use.  This sets an the HTTP_ACCEPT_LANGUAGE header
sent by the client to the server manager.  You may provide it with a
single language, eg. "en", or with a reference to a list of languages,
eg. [ qw(en de fr) ]

Sets $agent->{language} as a side effect, in case you want it for
anything later.

=begin testing

$agent->set_language("en");
is($WWW::Automate::headers{"Accept-Language"}, "en", "Set lang header in hash");
$agent->get("http://google.com");
is($agent->{req}->header("Accept-Language"), "en", "Set language header");

=end testing

=cut

sub set_language {
    my ($self, $language) = @_;
    $self->{language} = $language;
    $self->add_header("Accept-Language" => $language);
}

=head2 mode($script)

This convenience function is exported for use in testing scripts.  For
instance:

    use esmith::FormMagick::Tester;
    is(mode('useraccounts', 4755, "Setuid and executable");

=cut

sub mode {
    return sprintf("%04o", (stat($_[0]))[2] & 07777);
}


=head1 INTERNAL METHODS

The following methods are used internally by this module.

=head2 get_basic_credentials()

Returns the administrative login/password for the esmith manager.

=cut

sub get_basic_credentials {
    my $self = shift;
    return ("admin", $self->{password});
}

1;
