#!/usr/bin/perl -w 

#----------------------------------------------------------------------
# Copyright 1999-2003 Mitel Networks Corporation
# This program is free software; you can redistribute it and/or
# modify it under the same terms as Perl itself.
#
# $Id: LexTester.pm,v 1.1 2002/02/26 20:45:27 skud Exp $
#----------------------------------------------------------------------

package    esmith::FormMagick::LexTester;

my $VERSION = $VERSION = "0.10";

use esmith::FormMagick;
use strict;
use Carp;

our @ISA = qw(esmith::FormMagick);

#
# TODO
#
# 2002-02-18 Skud   Check for twice-translated terms
# 2002-02-18 Skud   Check the option labels of select/radio fields
#


=pod 

=head1 NAME

esmith::FormMagick::LexTester - test FormMagick lexicon completeness

=head1 SYNOPSIS

    use esmith::FormMagick::LexTester;

    my $lt = esmith::FormMagick::Lextester->new();

    foreach my $lang (qw(en fr de)) {
        my $ok = $lt->lextest($lang);
        unless ($ok) {
            my @untranslated = @{$lt->{untranslated}};
            warn "Untranslated terms for $lang: @untranslated\n",
        }
    }


=head1 DESCRIPTION

esmith::FormMagick::LexTester is a subclass of esmith::FormMagick whose
speciality is checking the completeness of localisation lexicons.

=head2 new();

Exactly as for esmith::FormMagick

=begin testing

BEGIN: {
    use lib qw(lib/ ../formmagick/lib/);
    use_ok('esmith::FormMagick::LexTester');
    use vars qw($lt);
}

ok(esmith::FormMagick::LexTester->can('new'), "We can call new");

ok($lt= esmith::FormMagick::LexTester->new(), "Create lt object");
isa_ok($lt, 'esmith::FormMagick::LexTester');

=end testing

=cut

sub new {
    shift;
    $ENV{HTTP_ACCEPT_LANGUAGE} = "test value";
    my $self = esmith::FormMagick->new();
    $self->{calling_package} = (caller)[0];
    $self->{untranslated} = [];
    bless $self;
    return $self;
}

=head2 $lt->lextest($lang)

Given a two-letter language code, checks the completeness of the lexicon
for that language.  Returns true on success, false on failure.  If it
fails, it sets $lt->{untranslated}, which is an arrayref containing a
list of strings to be translated.

=cut

sub lextest {
    my ($self, $lang) = @_;
    $ENV{HTTP_ACCEPT_LANGUAGE} = $lang;

    # we parse the XML a second time, even though it's wasteful... have to
    # do it to reset the lexicon to the language we want now.
    $self->parse_xml(); 

    $self->localise($self->{xml}->{title});

    foreach my $p (@{$self->{xml}->{pages}}) {
        $self->localise($p->{title});
        $self->localise($p->{description});
        foreach my $f (@{$p->{fields}}) {
            $self->localise($f->{label})
        }
    }

    open 0 or die "Can't open perl script for grepping: $!";
    LINE: while (my $line = <0>) {
        last LINE if $line =~ /^__DATA__/;
        while ($line =~ m/([A-Z_]{3,})/g) {
            $self->localise($1);
        }
    }
    close 0;

    if (@{$self->{untranslated}}) {
        return 0;
    } else {
        return 1;
    }
}

sub localise {
    my ($self, $string) = @_;
    my $result = $self->SUPER::localise($string);
    if ($string && $result eq $string) {
        $self->{untranslated} = [ @{$self->{untranslated}}, $string ];
    } 
    return $result;
}

1;
